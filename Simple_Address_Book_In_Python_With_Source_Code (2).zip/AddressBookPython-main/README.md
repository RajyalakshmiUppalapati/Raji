# Address Book implemented in python
## Plan

Step 1: Make CMD solution with temp storage

Step 2: Add permanent database

Step 3: Create Desktop UI

Step 4: Create Web version

Step 5: Create iOS app?

## Basic Requirements

- Contact info:
    - Name
    - Address
    - Email
    - Phone Number
- Add Contact
- Remove Contact
- Remove All Contacts
- List Contacts
- Search
- Search through contact info

## Advanced Requirements

- Import/Exporting to CSV

